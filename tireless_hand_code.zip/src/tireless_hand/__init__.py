"""Tireless Hand."""
