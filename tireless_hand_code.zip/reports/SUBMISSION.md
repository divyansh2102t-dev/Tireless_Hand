# Software Factory Series — The Tireless Hand Challenge
## Autonomous Agentic UI & Reliability Evaluation Document

---

## 1. System Design

### Architecture & Verification Pipeline

Tireless Hand is an autonomous end-to-end agentic quality verification system built on three core pillars:

1. **Deterministic DOM & Spatial Inspection (95% Tier)**
   - Operates directly on the browser's accessibility tree, extracting semantic roles, bounding boxes, and computed styles.
   - Evaluates multi-viewport responsiveness (Desktop 1280px, Tablet 768px, Mobile 375px) to catch clipped actions, horizontal overflows, and off-screen primary CTAs.

2. **Semantic Invariant & Security Verification Layer**
   - **Auth & Guard Auditor**: Audits route protection by launching isolated unauthenticated contexts and checking route guard boundaries.
   - **State Invariant Auditor**: Validates domain-specific rules (e.g., detecting impossible states where a device is marked 'Offline' while simultaneously broadcasting live telemetry feeds).
   - **Orphan Form Detector**: Catches broken flows where interactive input fields exist without actionable submit buttons.

3. **Tiered Local Reasoning Engine & Reproducible Video Evidence**
   - Runs on local Ollama models (Qwen2.5-Coder 1.5B / tireless-resolver) with zero external API dependencies.
   - Every single test scenario automatically records full-motion video (.webm), full-resolution defect screenshots, and network traces.

---

## 2. Evaluation Scenarios

### Scenario 1: Responsive Layout Defect (Desktop 1280px): ×
- **Category**: `Responsive UI`
- **Severity**: **HIGH**
- **Result**: `FAILED (Bug Caught)` (Issue caught by autonomous agent)
- **Video Recording**: [`page@afc40417a1b4a76e6ad768b154eb80b2.webm`](videos/page@afc40417a1b4a76e6ad768b154eb80b2.webm)
- **Visual Proof**: ![Responsive Layout Defect (Desktop 1280px): ×](screenshots/defect_scenario_1_1790416685.png)

#### Description
Actionable UI element or layout is clipped/unusable on Desktop screens.

#### Approach
Responsive Auditor cycled browser viewports down to mobile width (1280x720px) and measured bounding rects against viewport boundaries to catch horizontal overflow and clipped buttons.

#### Steps to Reproduce
1. Open browser and resize viewport to 1280x720 (Desktop).
2. Navigate to 'http://localhost:5173'.
3. Defect: [Desktop] Interactive element collapsed to 0 width/height

#### Evidence & Artifacts
[Desktop] Interactive element collapsed to 0 width/height

---

### Scenario 2: Responsive Layout Defect (Desktop 1280px): Data attribution
- **Category**: `Responsive UI`
- **Severity**: **HIGH**
- **Result**: `FAILED (Bug Caught)` (Issue caught by autonomous agent)
- **Video Recording**: [`page@afc40417a1b4a76e6ad768b154eb80b2.webm`](videos/page@afc40417a1b4a76e6ad768b154eb80b2.webm)
- **Visual Proof**: ![Responsive Layout Defect (Desktop 1280px): Data attribution](screenshots/defect_scenario_2_1790416685.png)

#### Description
Actionable UI element or layout is clipped/unusable on Desktop screens.

#### Approach
Responsive Auditor cycled browser viewports down to mobile width (1280x720px) and measured bounding rects against viewport boundaries to catch horizontal overflow and clipped buttons.

#### Steps to Reproduce
1. Open browser and resize viewport to 1280x720 (Desktop).
2. Navigate to 'http://localhost:5173'.
3. Defect: [Desktop] Interactive element collapsed to 0 width/height

#### Evidence & Artifacts
[Desktop] Interactive element collapsed to 0 width/height

---

### Scenario 3: Responsive Layout Defect (Tablet 768px): ×
- **Category**: `Responsive UI`
- **Severity**: **HIGH**
- **Result**: `FAILED (Bug Caught)` (Issue caught by autonomous agent)
- **Video Recording**: [`page@afc40417a1b4a76e6ad768b154eb80b2.webm`](videos/page@afc40417a1b4a76e6ad768b154eb80b2.webm)
- **Visual Proof**: ![Responsive Layout Defect (Tablet 768px): ×](screenshots/defect_scenario_3_1790416690.png)

#### Description
Actionable UI element or layout is clipped/unusable on Tablet screens.

#### Approach
Responsive Auditor cycled browser viewports down to mobile width (768x1024px) and measured bounding rects against viewport boundaries to catch horizontal overflow and clipped buttons.

#### Steps to Reproduce
1. Open browser and resize viewport to 768x1024 (Tablet).
2. Navigate to 'http://localhost:5173'.
3. Defect: [Tablet] Interactive element collapsed to 0 width/height

#### Evidence & Artifacts
[Tablet] Interactive element collapsed to 0 width/height

---

### Scenario 4: Responsive Layout Defect (Tablet 768px): Data attribution
- **Category**: `Responsive UI`
- **Severity**: **HIGH**
- **Result**: `FAILED (Bug Caught)` (Issue caught by autonomous agent)
- **Video Recording**: [`page@afc40417a1b4a76e6ad768b154eb80b2.webm`](videos/page@afc40417a1b4a76e6ad768b154eb80b2.webm)
- **Visual Proof**: ![Responsive Layout Defect (Tablet 768px): Data attribution](screenshots/defect_scenario_4_1790416690.png)

#### Description
Actionable UI element or layout is clipped/unusable on Tablet screens.

#### Approach
Responsive Auditor cycled browser viewports down to mobile width (768x1024px) and measured bounding rects against viewport boundaries to catch horizontal overflow and clipped buttons.

#### Steps to Reproduce
1. Open browser and resize viewport to 768x1024 (Tablet).
2. Navigate to 'http://localhost:5173'.
3. Defect: [Tablet] Interactive element collapsed to 0 width/height

#### Evidence & Artifacts
[Tablet] Interactive element collapsed to 0 width/height

---

### Scenario 5: Responsive Layout Defect (Mobile 375px): ×
- **Category**: `Responsive UI`
- **Severity**: **HIGH**
- **Result**: `FAILED (Bug Caught)` (Issue caught by autonomous agent)
- **Video Recording**: [`page@afc40417a1b4a76e6ad768b154eb80b2.webm`](videos/page@afc40417a1b4a76e6ad768b154eb80b2.webm)
- **Visual Proof**: ![Responsive Layout Defect (Mobile 375px): ×](screenshots/defect_scenario_5_1790416691.png)

#### Description
Actionable UI element or layout is clipped/unusable on Mobile screens.

#### Approach
Responsive Auditor cycled browser viewports down to mobile width (375x667px) and measured bounding rects against viewport boundaries to catch horizontal overflow and clipped buttons.

#### Steps to Reproduce
1. Open browser and resize viewport to 375x667 (Mobile).
2. Navigate to 'http://localhost:5173'.
3. Defect: [Mobile] Interactive element collapsed to 0 width/height

#### Evidence & Artifacts
[Mobile] Interactive element collapsed to 0 width/height

---

### Scenario 6: Responsive Layout Defect (Mobile 375px): Data attribution
- **Category**: `Responsive UI`
- **Severity**: **HIGH**
- **Result**: `FAILED (Bug Caught)` (Issue caught by autonomous agent)
- **Video Recording**: [`page@afc40417a1b4a76e6ad768b154eb80b2.webm`](videos/page@afc40417a1b4a76e6ad768b154eb80b2.webm)
- **Visual Proof**: ![Responsive Layout Defect (Mobile 375px): Data attribution](screenshots/defect_scenario_6_1790416692.png)

#### Description
Actionable UI element or layout is clipped/unusable on Mobile screens.

#### Approach
Responsive Auditor cycled browser viewports down to mobile width (375x667px) and measured bounding rects against viewport boundaries to catch horizontal overflow and clipped buttons.

#### Steps to Reproduce
1. Open browser and resize viewport to 375x667 (Mobile).
2. Navigate to 'http://localhost:5173'.
3. Defect: [Mobile] Interactive element collapsed to 0 width/height

#### Evidence & Artifacts
[Mobile] Interactive element collapsed to 0 width/height

---

### Scenario 7: Security Auth Bypass: Unprotected Route fleet
- **Category**: `Security and permissions`
- **Severity**: **CRITICAL**
- **Result**: `FAILED (Bug Caught)` (Issue caught by autonomous agent)
- **Video Recording**: [`page@afc40417a1b4a76e6ad768b154eb80b2.webm`](videos/page@afc40417a1b4a76e6ad768b154eb80b2.webm)
- **Visual Proof**: ![Security Auth Bypass: Unprotected Route fleet](screenshots/defect_scenario_7_1790416698.png)

#### Description
Unauthenticated user can access protected route '/fleet' without sign-in

#### Approach
Security Auditor initialized an unauthenticated browser context with zero cookies/tokens and executed direct HTTP GET to 'http://localhost:5173/fleet', evaluating response code and DOM exposure.

#### Steps to Reproduce
1. Launch a clean incognito / unauthenticated browser session (no auth cookies).
2. Navigate directly to 'http://localhost:5173/fleet'.
3. Observe that private dashboard data loads without redirecting to login. Details: Direct GET request to http://localhost:5173/fleet rendered protected page (Title: 'FlytBase Cockpit', HTTP 200) without redirecting to login.

#### Evidence & Artifacts
Direct GET request to http://localhost:5173/fleet rendered protected page (Title: 'FlytBase Cockpit', HTTP 200) without redirecting to login.

---

### Scenario 8: Security Auth Bypass: Unprotected Route settings
- **Category**: `Security and permissions`
- **Severity**: **CRITICAL**
- **Result**: `FAILED (Bug Caught)` (Issue caught by autonomous agent)
- **Video Recording**: [`page@afc40417a1b4a76e6ad768b154eb80b2.webm`](videos/page@afc40417a1b4a76e6ad768b154eb80b2.webm)
- **Visual Proof**: ![Security Auth Bypass: Unprotected Route settings](screenshots/defect_scenario_8_1790416698.png)

#### Description
Unauthenticated user can access protected route '/settings' without sign-in

#### Approach
Security Auditor initialized an unauthenticated browser context with zero cookies/tokens and executed direct HTTP GET to 'http://localhost:5173/settings', evaluating response code and DOM exposure.

#### Steps to Reproduce
1. Launch a clean incognito / unauthenticated browser session (no auth cookies).
2. Navigate directly to 'http://localhost:5173/settings'.
3. Observe that private dashboard data loads without redirecting to login. Details: Direct GET request to http://localhost:5173/settings rendered protected page (Title: 'FlytBase Cockpit', HTTP 200) without redirecting to login.

#### Evidence & Artifacts
Direct GET request to http://localhost:5173/settings rendered protected page (Title: 'FlytBase Cockpit', HTTP 200) without redirecting to login.

---

### Scenario 9: Security Auth Bypass: Unprotected Route mission-control
- **Category**: `Security and permissions`
- **Severity**: **CRITICAL**
- **Result**: `FAILED (Bug Caught)` (Issue caught by autonomous agent)
- **Video Recording**: [`page@afc40417a1b4a76e6ad768b154eb80b2.webm`](videos/page@afc40417a1b4a76e6ad768b154eb80b2.webm)
- **Visual Proof**: ![Security Auth Bypass: Unprotected Route mission-control](screenshots/defect_scenario_9_1790416699.png)

#### Description
Unauthenticated user can access protected route '/mission-control' without sign-in

#### Approach
Security Auditor initialized an unauthenticated browser context with zero cookies/tokens and executed direct HTTP GET to 'http://localhost:5173/mission-control', evaluating response code and DOM exposure.

#### Steps to Reproduce
1. Launch a clean incognito / unauthenticated browser session (no auth cookies).
2. Navigate directly to 'http://localhost:5173/mission-control'.
3. Observe that private dashboard data loads without redirecting to login. Details: Direct GET request to http://localhost:5173/mission-control rendered protected page (Title: 'FlytBase Cockpit', HTTP 200) without redirecting to login.

#### Evidence & Artifacts
Direct GET request to http://localhost:5173/mission-control rendered protected page (Title: 'FlytBase Cockpit', HTTP 200) without redirecting to login.

---

### Scenario 10: Security Auth Bypass: Unprotected Route admin
- **Category**: `Security and permissions`
- **Severity**: **CRITICAL**
- **Result**: `FAILED (Bug Caught)` (Issue caught by autonomous agent)
- **Video Recording**: [`page@afc40417a1b4a76e6ad768b154eb80b2.webm`](videos/page@afc40417a1b4a76e6ad768b154eb80b2.webm)
- **Visual Proof**: ![Security Auth Bypass: Unprotected Route admin](screenshots/defect_scenario_10_1790416700.png)

#### Description
Unauthenticated user can access protected route '/admin' without sign-in

#### Approach
Security Auditor initialized an unauthenticated browser context with zero cookies/tokens and executed direct HTTP GET to 'http://localhost:5173/admin', evaluating response code and DOM exposure.

#### Steps to Reproduce
1. Launch a clean incognito / unauthenticated browser session (no auth cookies).
2. Navigate directly to 'http://localhost:5173/admin'.
3. Observe that private dashboard data loads without redirecting to login. Details: Direct GET request to http://localhost:5173/admin rendered protected page (Title: 'FlytBase Cockpit', HTTP 200) without redirecting to login.

#### Evidence & Artifacts
Direct GET request to http://localhost:5173/admin rendered protected page (Title: 'FlytBase Cockpit', HTTP 200) without redirecting to login.

---

### Scenario 11: Security Auth Bypass: Unprotected Route dashboard
- **Category**: `Security and permissions`
- **Severity**: **CRITICAL**
- **Result**: `FAILED (Bug Caught)` (Issue caught by autonomous agent)
- **Video Recording**: [`page@afc40417a1b4a76e6ad768b154eb80b2.webm`](videos/page@afc40417a1b4a76e6ad768b154eb80b2.webm)
- **Visual Proof**: ![Security Auth Bypass: Unprotected Route dashboard](screenshots/defect_scenario_11_1790416701.png)

#### Description
Unauthenticated user can access protected route '/dashboard' without sign-in

#### Approach
Security Auditor initialized an unauthenticated browser context with zero cookies/tokens and executed direct HTTP GET to 'http://localhost:5173/dashboard', evaluating response code and DOM exposure.

#### Steps to Reproduce
1. Launch a clean incognito / unauthenticated browser session (no auth cookies).
2. Navigate directly to 'http://localhost:5173/dashboard'.
3. Observe that private dashboard data loads without redirecting to login. Details: Direct GET request to http://localhost:5173/dashboard rendered protected page (Title: 'FlytBase Cockpit', HTTP 200) without redirecting to login.

#### Evidence & Artifacts
Direct GET request to http://localhost:5173/dashboard rendered protected page (Title: 'FlytBase Cockpit', HTTP 200) without redirecting to login.

---
