# Level 2 Submission — Performance & Domain-Specific Reliability Testing

**Project Name:** Tireless Hand — Autonomous UI & Reliability Testing System  
**Category:** Level 2: Getting Into Your Domain (Performance & Complex Domain Testing)  
**Target Application:** FlytBase Drone Operations & Mission Control Platform  
**Evaluation Results:** **100% Precision | 100% Recall | 100% Accuracy | 1.000 F1-Score**

---

## Part 1: System Design

### 1.1 Overview & Architecture
Tireless Hand's Level 2 subsystem is built specifically for high-throughput, low-latency autonomous drone management platforms. Unlike generic web testing tools that only check DOM visibility, Tireless Hand continuously evaluates real-time streaming constraints, UI thread responsiveness, rendering performance of 3D globe canvases (Cesium / WebGL), and browser memory stability during sustained telemetry streaming.

```
+-----------------------------------------------------------------------------------+
|                           TIRELESS HAND LEVEL 2 ARCHITECTURE                     |
+-----------------------------------------------------------------------------------+
|                                                                                   |
|  [ Playwright CDP Instrumentation ] <---> [ Headless Chromium Engine ]            |
|               |                                      |                            |
|               v                                      v                            |
|  +-----------------------------------------------------------------------------+  |
|  |                        Performance Auditor Engine                           |  |
|  |  * Core Web Vitals (LCP via Paint Timing, CLS via LayoutShift Observer)     |  |
|  |  * Main-Thread Task Profiler (Long Tasks > 50ms, Total Blocking Time)       |  |
|  |  * High-Frequency Frame Rate Monitor (60 FPS requestAnimationFrame loop)    |  |
|  |  * JS Heap Delta Tracker (performance.memory & CDP Heap Sampling)           |  |
|  +-----------------------------------------------------------------------------+  |
|               |                                      |                            |
|               v                                      v                            |
|  +---------------------------+       +-----------------------------------------+  |
|  | Domain Telemetry Analyzer |       |     AI Root-Cause Reasoner (LLM)        |  |
|  | * Buffer jitter detection | ----> |  * Maps metrics to flight safety impact |  |
|  | * Unbounded stream leaks  |       |  * Generates remediation suggestions    |  |
|  +---------------------------+       +-----------------------------------------+  |
|               |                                      |                            |
|               +-------------------+------------------+                            |
|                                   |                                               |
|                                   v                                               |
|  +-----------------------------------------------------------------------------+  |
|  |                     Verifiable Multi-Format Evidence Engine                 |  |
|  |  * Annotated Frame Rate Curves & Heap Growth Profiles (JSON & MD)           |  |
|  |  * High-Res Visual Proofs (PNG) + Synchronized Interaction Videos (WebM)    |  |
|  +-----------------------------------------------------------------------------+  |
+-----------------------------------------------------------------------------------+
```

### 1.2 Core Components & Responsibilities

1. **In-Flight Pre-Navigation Instrumentation (`PerformanceAuditor`):**
   - Injects zero-overhead `PerformanceObserver` instances before DOM construction to capture early lifecycle metrics (`largest-contentful-paint`, `layout-shift`, `longtask`).
   - Runs an asynchronous, high-precision frame rate sampler via `requestAnimationFrame` to measure visual rendering jitter without skewing test metrics.

2. **Core Web Vitals & Main-Thread Blocking Evaluation:**
   - **Largest Contentful Paint (LCP):** Validates that heavy satellite imagery, drone orientation HUDs, and mission maps render within strict operational safety thresholds ($\le 3.2\text{s}$).
   - **Cumulative Layout Shift (CLS):** Detects layout instability caused by unbuffered incoming telemetry packets inserted into live dashboard views ($\le 0.10$).
   - **Long Tasks & Total Blocking Time (TBT):** Detects heavy JS event loop blocking ($>50\text{ms}$ and $>120\text{ms}$) that could freeze emergency commands (e.g. Return-To-Home or Auto-Land clicks).

3. **Continuous Telemetry & Memory Profiling:**
   - Samples JavaScript heap memory (`usedJSHeapSize`) before, during, and after sustained telemetry polling.
   - Flags continuous unbounded heap accumulation ($>15\text{MB}$ delta) caused by uncollected WebSocket listeners, cached video packets, or un-disposed 3D flight path coordinates.

4. **Multi-Viewport Domain Validation:**
   - Evaluates performance consistency across Desktop (1280px), Tablet (768px), and Mobile (375px) viewports to verify emergency controls remain responsive on mobile field devices.

---

## Part 2: Scenarios & Performance Failure Modes

Tireless Hand was benchmarked against eight rigorous performance scenarios representing real-world drone command center challenges.

| Vector ID | Scenario Name | Domain Constraint / Performance Vector | Expected | Detected | Result |
|---|---|---|---|---|---|
| **PERF-01** | Clean Drone Cockpit Baseline | FlytBase Cesium 3D Globe & Live Stream (Port 5173) | Clean | Clean | **TN (True Negative)** |
| **PERF-02** | Clean Control Panel Baseline | Multi-drone telemetry dashboard (Port 4000) | Clean | Clean | **TN (True Negative)** |
| **PERF-03** | Clean Mission Planner Baseline | Autonomous waypoint planning interface | Clean | Clean | **TN (True Negative)** |
| **PERF-04** | Clean Diagnostics Stream Baseline | Real-time IMU / Barometer telemetry feed | Clean | Clean | **TN (True Negative)** |
| **PERF-05** | Heavy Flight Map (High LCP) | Delayed 3D satellite tile asset hydration ($>3500\text{ms}$) | Defect | Defect | **TP (True Positive)** |
| **PERF-06** | Unbuffered Telemetry (High CLS) | Dynamic insertion of streaming alerts shifting UI | Defect | Defect | **TP (True Positive)** |
| **PERF-07** | Blocking Telemetry Parsing | Synchronous parsing of high-rate telemetry ($>140\text{ms}$) | Defect | Defect | **TP (True Positive)** |
| **PERF-08** | Flight Session Memory Leak | Unbounded JS heap accumulation during streaming | Defect | Defect | **TP (True Positive)** |

### 2.1 Detailed Scenario Breakdown

#### Scenario 1: Clean Baseline Cockpit & Control Panel (PERF-01 to PERF-04)
- **Target:** FlytBase Cesium 3D Globe (`http://localhost:5173`) and Telemetry Panel (`http://localhost:4000/dashboard`).
- **Behavior:** Renders smooth 60 FPS interfaces on standard pages with zero layout shifts, zero main-thread blocking, and stable memory consumption.
- **Tireless Hand Decision:** Accurately classified as **Clean (Pass)** with zero false alarms.

#### Scenario 2: High LCP on Heavy Flight Map (PERF-05)
- **Failure Mode:** A flight map screen delays primary visual rendering past $3.6\text{s}$, delaying critical situational awareness for the drone pilot.
- **Observed Metrics:** $\text{LCP} = 3600.0\text{ms}$ (Threshold $\le 3200\text{ms}$, Status: POOR).
- **Remediation:** Preload top-priority map vector tiles, split non-critical route calculation bundles, and utilize CDN-cached glTF assets.

#### Scenario 3: Unbuffered Telemetry Ingestion Causing Cumulative Layout Shift (PERF-06)
- **Failure Mode:** Inbound WebSocket telemetry messages inject alerts and status bars directly into the DOM without reserved dimensional bounding boxes, shifting the "Return-To-Home" (RTH) button downward.
- **Observed Metrics:** $\text{CLS} = 0.284$ (Threshold $\le 0.100$, Status: POOR).
- **Remediation:** Reserve explicit CSS min-height and aspect-ratio placeholders for dynamic telemetry and video feeds.

#### Scenario 4: Long Tasks & Main Thread UI Freeze (PERF-07)
- **Failure Mode:** Heavy synchronous parsing of 500Hz IMU coordinate matrices in the main UI thread freezes button clicks and user interactions for $180\text{ms}$ every 350ms.
- **Observed Metrics:** 3+ Long Tasks $>120\text{ms}$ detected (Max block: $180.0\text{ms}$, Status: NEEDS_IMPROVEMENT).
- **Remediation:** Offload JSON / Protobuf telemetry decoding and coordinate transform mathematics to dedicated Web Workers.

#### Scenario 5: Flight Session Memory Leak (PERF-08)
- **Failure Mode:** Drone flight breadcrumb coordinates and uncollected WebSocket event listeners accumulate in memory continuously without garbage collection.
- **Observed Metrics:** Heap memory delta: $+18.45\text{MB}$ in $2.0\text{s}$ (Threshold $\le 15.0\text{MB}$, Severity: CRITICAL).
- **Remediation:** Ensure WebSocket subscriptions and Cesium polyline primitive buffers are disposed on component destruction and circular telemetry buffers are capped.

---

## Part 3: Quantitative Evaluation & Results

```
================================================================================
                    TIRELESS HAND LEVEL 2 EVALUATION SUMMARY
================================================================================
Total Evaluated Scenarios:   8 vectors (4 Baselines + 4 Domain Mutations)
True Positives (TP):          4 (100% of performance bugs caught)
True Negatives (TN):          4 (0% false positives on clean baselines)
False Positives (FP):         0
False Negatives (FN):         0
--------------------------------------------------------------------------------
Precision:                    100.0% (1.0000)
Recall:                       100.0% (1.0000)
Accuracy:                     100.0% (1.0000)
F1-Score:                     100.0% (1.0000)
Total Evaluation Time:        27.46 seconds
================================================================================
```

---

## Part 4: Reproduction Instructions

To reproduce the Level 2 benchmark and test suite locally:

```bash
# 1. Start the FlytBase mock control and demo server
python demo/app.py

# 2. Run the Level 2 Performance & Domain Testing Benchmark
python benchmarks/run_level2_perf_benchmark.py

# 3. View the JSON benchmark output
cat reports/level2_benchmark_results.json
```
