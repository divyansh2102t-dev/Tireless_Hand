# 🤖 The Tireless Hand — Implementation Plan

## Autonomous UI Testing Agent — Zero-Cost, Fully Local

> **No API keys. No cloud bills. Everything runs on your RTX 3050 via Ollama.**

---

## Quick Start (5 minutes)

```bash
# 1. Pull the 7B model (you already have 1.5b + llava)
ollama pull qwen2.5-coder:7b

# 2. Install project
pip install -e ".[dev]"

# 3. Install browsers
playwright install chromium

# 4. Copy config
copy .env.example .env

# 5. Run
tireless explore https://example.com
tireless test --app example.com --heal
```

## Architecture

```
┌─────────────────────────────────────────────────────┐
│                  CLI (click)                         │
│  explore | test | generate | report | status        │
└─────────────────┬───────────────────────────────────┘
                  │
┌─────────────────▼───────────────────────────────────┐
│            Test Orchestrator                         │
│  Coordinates exploration, testing, reporting         │
└──┬──────────────┬──────────────┬────────────────────┘
   │              │              │
┌──▼──────┐ ┌────▼─────┐ ┌─────▼──────┐
│ Browser │ │ Self-    │ │ Reasoning  │
│ Layer   │ │ Healing  │ │ (Ollama)   │
│         │ │ Engine   │ │            │
│ Playwright│ │Fingerprint│ │Qwen 1.5B  │
│ DOM Parse│ │Fuzzy Match│ │Qwen 7B    │
│ Screenshot│ │AI Resolve│ │LLaVA      │
└──┬──────┘ └────┬─────┘ └─────┬──────┘
   │              │              │
┌──▼──────────────▼──────────────▼────────────────────┐
│          Persistent Memory (SQLite)                  │
│  App Graph | Elements | Baselines | Healing Log      │
└─────────────────────────────────────────────────────┘
```

## Model Strategy (All Local, All Free)

| Tier | Model | Use | Speed |
|------|-------|-----|-------|
| 0 | None (deterministic) | Exact/fuzzy selector match | <10ms |
| 1 | qwen2.5-coder:1.5b | Simple element resolution | ~50ms |
| 2 | qwen2.5-coder:7b | Bug analysis, test gen | ~200ms |
| 3 | llava:latest | Visual fallback | ~500ms |

**95% of actions use Tier 0 (no AI at all).**

## Self-Healing Cascade

1. Exact Playwright locator → FREE, <5ms
2. Fingerprint fuzzy match → FREE, <10ms  
3. Qwen 1.5B DOM resolver → LOCAL, ~50ms
4. Qwen 7B + context → LOCAL, ~200ms
5. LLaVA screenshot → LOCAL, ~500ms
6. Report unresolvable → Human needed

## Bug vs Feature Detection

**Heuristic rules first (no AI for 80% of cases):**
- Error keywords / HTTP 4xx-5xx → BUG
- Multiple coordinated changes → FEATURE
- Element moved, same attributes → MOVED (self-heal)
- Text/style only change → COSMETIC
- Ambiguous → Ask Qwen 7B

## Optional: Fine-Tune Custom DOM Model

```bash
# Generate training data from real websites
tireless generate-training-data --urls urls.txt

# Create custom Ollama model
ollama create tireless-resolver -f training/Modelfile
```

Fine-tuning Qwen 1.5B on 1000 examples takes ~15 min on RTX 3050.
Result: Element resolution in <20ms with 95%+ accuracy.
